const Explore = ({ opt }) => {
    return (
      <div className="showCard bg-dark text-white  d-flex flex-wrap gap-5 justify-content-center">
        {opt &&
          opt.map((item, key) => (
            <div>
              {/* <ul key={key}>
                <li> {item.released}</li>
                <li> {item.imdbid}</li>
                <li>{item.title}</li>
                <li>{item.synopsis}</li>
                <li><img src={item.imageurl}/></li>
                <li>{item.type}</li>
                <li>{item.imdbrating}</li>
                <li>{item.genre}</li>
              

              </ul> */}





              {/* {item?.i && <img src={item?.i?.imageUrl} alt={item.l} />} */}
              {/* <img src={item?.imageUrl}/> */}


              <div class="card bg-black  text-white  text-start" key={key} >
     <div className="forimgwidth ">
     { item ? <img src={item.imageurl} class="card-img-top" alt="..."/>:<img src="https://static.tvtropes.org/pmwiki/pub/images/slappybook.jpg" alt="dummy image" className="img-fluid"/>};
     </div>

     {/* <div className="forimgwidth"> {item.i ? <img src={item?.i?.imageUrl} alt={item.l} className="img-fluid forimgwidth" />:<img src="https://static.tvtropes.org/pmwiki/pub/images/slappybook.jpg" alt="dummy image" className="img-fluid"/>};</div> */}
  <div class="card-body ">
    <h5 class="card-title fw-bold ">Movie Name:- {item.title}</h5>
    <p class="card-text fw-bold  ">Id:- {item.imdbid}</p>
    <p class="card-text fw-bold  ">Synopsis:- {item.synopsis}</p>
    <p class="card-text fw-bold  ">Type:- {item.type}</p>
    <p class="card-text fw-bold  ">Gern:- {item.genre}</p>
    <p class="card-text fw-bold t">Imdbrating:-{item.imdbrating}</p>
    <p class="card-text fw-bold  ">Released:- {item.released}</p>
  </div>
  {/* <ul class="list-group list-group-flush border-0 ">

  <li class="list-group-item fw-bold">Type:- {item.type}</li>
  <li class="list-group-item fw-bold">Gern:- {item.genre}</li>

    <li class="list-group-item lead fw-bold ">Relased Year:- {item.yr}</li>
    <li class="list-group-item  fw-bold">Imdbrating:-{item.imdbrating}</li>
    <li class="list-group-item fw-bold"> Released:- {item.released}</li>
    <li class="list-group-item fw-bold">Show:-{item.synopsis}</li>
   
  </ul> */}
 
</div>
            </div>
          ))}
      </div>
    );
  };
  
  export default Explore;